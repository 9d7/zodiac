% reads a CVS of transactions to build a portfolio
% does not use the API because i can't figure out how it works

function P = transactions2Portfolio(filename)